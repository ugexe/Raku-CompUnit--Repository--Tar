<!--- Provide a general summary of the issue in the Title above -->

## Context
<!--- Provide a more detailed introduction to the issue itself, and why you consider it to be a bug -->

## Expected Behavior
<!--- Tell us what should happen -->

## Actual Behavior
<!--- Tell us what happens instead -->

## Steps to Reproduce
<!--- Provide a unambiguous set of steps to reproduce this bug. -->
<!--- Please use the --debug flag: e.g. `zef --debug ...` -->

## Your Environment
<!--- Show the output from the following commands to tell us more about your environment -->
* raku -v
* zef list --installed
